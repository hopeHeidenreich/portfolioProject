var express = require('express');
const mongodb = require('mongodb');
const mongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017/portfolio';
var router = express.Router();

const client = new mongoClient(url, { useUnifiedTopology: true });
client.connect();

router.get('/', function(req, res, next) {
  res.render('index');
});


router.get('/findOne', async (req, res) => {
  await client.db().collection('projects').find().toArray((err, result) => {
    if (err) throw err;
    res.send(JSON.stringify(result));
    res.end();
  });
});
//router.get('/findTwo', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findThree', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findFour', async (req, res) => {
//  await client.db().collection('projects').find({date: "01/06/22"}).toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findFive', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findSix', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findSev', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findEig', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});
//router.get('/findNine', async (req, res) => {
//  await client.db().collection('projects').find().toArray((err, result) => {
//    if (err) throw err;
//    res.send(JSON.stringify(result));
//    res.end();
//  });
//});

module.exports = router;
