var express = require('express');
var http = require('http');
var path = require('path');
var logger = require('morgan');
var mime = require('mime');
var mime2 = require('mime-types')
var cookieParser = require('cookie-parser');

var app = express();

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'html');
app.engine('html', require('ejs').renderFile);

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use(require('./routes/index'));

var port = process.env.PORT || '3001';
app.set('port', port);
var server = http.createServer(app);
server.listen(port);

console.log('Server listening on port: ' + port);
console.log(`Click the following link to run the server: http://localhost:${port}`);



module.exports = app;